const grid = document.getElementById("grid");
const emptyMsg = document.getElementById("empty");
const catsWrap = document.getElementById("cats");
const searchInput = document.getElementById("search");
const overlay = document.getElementById("overlay");
const playerFrame = document.getElementById("player-frame");
const playerTitle = document.getElementById("player-title");
const playerDot = document.getElementById("player-dot");
const closeBtn = document.getElementById("close-btn");

let activeCategory = "All";
let query = "";

const categories = ["All", ...new Set(GAMES.map((g) => g.category))];

function renderCategories() {
  catsWrap.innerHTML = "";
  categories.forEach((cat) => {
    const btn = document.createElement("button");
    btn.className = "cat-btn" + (cat === activeCategory ? " active" : "");
    btn.textContent = cat;
    btn.addEventListener("click", () => {
      activeCategory = cat;
      renderCategories();
      renderGrid();
    });
    catsWrap.appendChild(btn);
  });
}

function renderGrid() {
  const filtered = GAMES.filter((g) => {
    const matchesCat = activeCategory === "All" || g.category === activeCategory;
    const matchesQuery = g.title.toLowerCase().includes(query.toLowerCase());
    return matchesCat && matchesQuery;
  });

  grid.innerHTML = "";
  emptyMsg.style.display = filtered.length ? "none" : "block";

  filtered.forEach((game) => {
    const card = document.createElement("button");
    card.className = "card";

    card.innerHTML = `
      <div class="marquee" style="background:${game.color}"></div>
      <div class="screen">
        ${game.icon}
        <div class="play-label" style="color:${game.color}">Play</div>
      </div>
      <div class="label">
        <p class="title">${game.title}</p>
        <p class="cat">${game.category}</p>
      </div>
    `;

    card.addEventListener("mouseenter", () => {
      card.style.boxShadow = `0 0 24px ${game.color}55`;
    });
    card.addEventListener("mouseleave", () => {
      card.style.boxShadow = "none";
    });
    card.addEventListener("click", () => openGame(game));

    grid.appendChild(card);
  });
}

function openGame(game) {
  playerTitle.textContent = game.title;
  playerDot.style.background = game.color;
  document.getElementById("frame-wrap").style.borderColor = game.color;
  playerFrame.src = game.url;
  overlay.classList.add("open");
}

function closePlayer() {
  overlay.classList.remove("open");
  playerFrame.src = "about:blank"; // stop game execution / audio
}

closeBtn.addEventListener("click", closePlayer);
overlay.addEventListener("click", (e) => {
  if (e.target === overlay) closePlayer();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closePlayer();
});

searchInput.addEventListener("input", (e) => {
  query = e.target.value;
  renderGrid();
});

renderCategories();
renderGrid();
