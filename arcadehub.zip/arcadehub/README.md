# ArcadeHub

A working game hub, styled like a neon arcade. Search and filter games, click a
card, and it opens in a player overlay — everything runs locally in the browser,
no build step, no backend required.

## Folder structure

```
arcadehub/
├── index.html          ← the hub page
├── style.css
├── app.js               ← rendering, search, filter, player logic
├── games-data.js         ← the game catalog — edit this to add games
└── games/
    ├── snake/index.html
    ├── memory/index.html
    ├── twenty48/index.html
    ├── chess/index.html      ← Player vs Player, or Player vs Computer
    ├── carrace/index.html
    ├── ludo/index.html       ← 2-4 local players, pass-and-play
    ├── penalty/index.html
    └── football/index.html
```

## Notes on the new games

- **Chess**: full legal-move validation (no illegal or into-check moves), check/checkmate/stalemate detection, pawn auto-promotes to queen. Not implemented: castling and en passant. The computer opponent uses a simple greedy heuristic (prefers captures, slight bias toward the center) — good for casual play, not a strong engine.
- **Ludo**: standard 52-square track with safe squares, capturing, and a 6-to-exit rule, for 2–4 local players passing the device each turn. No online/networked play.
- **Football**: simplified 1-vs-1 arcade version (you vs. one CPU defender/attacker), not full 11-a-side.
- **Car Race**, **Penalty Shootout**: self-contained arcade minigames, no external assets.

## Run it

No install needed. Two options:

1. **Just open it.** Double-click `index.html`. (Some browsers restrict iframes
   loaded via `file://` — if a game doesn't load, use option 2.)
2. **Local server (recommended).** From the `arcadehub` folder:
   ```
   python3 -m http.server 8000
   ```
   Then visit `http://localhost:8000` in your browser.

## Add a new game

1. Make a folder under `games/`, e.g. `games/pong/`.
2. Put a self-contained `index.html` in it (inline CSS/JS is easiest, like the
   three included games).
3. Add one entry to `games-data.js`:
   ```js
   {
     id: "pong",
     title: "Pong",
     category: "Arcade",
     color: "#8b5cf6",
     icon: "🏓",
     url: "games/pong/index.html",
   }
   ```
That's it — it appears in the grid and search automatically.

## Deploy it for free

Any static host works since there's no backend:
- **GitHub Pages**: push this folder to a repo, enable Pages in repo settings.
- **Netlify / Vercel**: drag-and-drop the folder in their dashboard, or connect
  a GitHub repo for auto-deploys.
- **Cloudflare Pages**: same idea, generous free tier.

## Growing beyond this

This is a static hub — great for a handful of games you build or license
yourself. If you want accounts, favorites, leaderboards, or hundreds of games
from outside developers, you'll eventually want:
- A framework like Next.js (routing per game, server-rendered pages for SEO)
- A database (Supabase/Postgres) for game metadata, users, and scores
- A real rights arrangement for any game you didn't build yourself —
  services like CrazyGames run on publisher agreements, not scraped embeds

## A note on other people's games

The three included games (Snake, Memory Match, 2048) are original code, safe
to use and modify freely. Don't iframe games from other sites unless the
game's own creator has explicitly provided an embed code for that purpose
(itch.io does this for games marked "embed in page") — otherwise it's a
copyright/ToS problem, not a coding problem.
