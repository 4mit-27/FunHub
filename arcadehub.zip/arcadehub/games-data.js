// ---------------------------------------------------------------
// GAME CATALOG
// To add a new game: build its HTML/CSS/JS in a folder under /games,
// then add one entry here pointing to it. That's the entire process.
// ---------------------------------------------------------------
const GAMES = [
  {
    id: "snake",
    title: "Neon Snake",
    category: "Arcade",
    color: "#ff2fb8",
    icon: "🐍",
    url: "games/snake/index.html",
  },
  {
    id: "memory",
    title: "Memory Match",
    category: "Puzzle",
    color: "#2fe8ff",
    icon: "🧠",
    url: "games/memory/index.html",
  },
  {
    id: "2048",
    title: "2048",
    category: "Puzzle",
    color: "#ffb32f",
    icon: "🔢",
    url: "games/twenty48/index.html",
  },
  {
    id: "chess",
    title: "Chess",
    category: "Strategy",
    color: "#8b5cf6",
    icon: "♟️",
    url: "games/chess/index.html",
  },
  {
    id: "carrace",
    title: "Car Race",
    category: "Racing",
    color: "#ff2fb8",
    icon: "🏎️",
    url: "games/carrace/index.html",
  },
  {
    id: "ludo",
    title: "Ludo",
    category: "Board",
    color: "#ffb32f",
    icon: "🎲",
    url: "games/ludo/index.html",
  },
  {
    id: "penalty",
    title: "Penalty Shootout",
    category: "Sports",
    color: "#2fe8ff",
    icon: "🥅",
    url: "games/penalty/index.html",
  },
  {
    id: "football",
    title: "Football",
    category: "Sports",
    color: "#8b5cf6",
    icon: "⚽",
    url: "games/football/index.html",
  },
];
